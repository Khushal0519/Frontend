angular.module('profileApp', [])
    .controller('ProfileController', function($scope) {
        // Predefined profiles
        $scope.profiles = [
            { name: "Rajesh Patel", description: "Software Engineer at Tech Solutions Pvt. Ltd.", photoUrl: "P.jpg", location: "Pune,+Maharashtra/Survey+No+2,+Vishwakarma+University,+3,4,+Kondhwa+Main+Rd,+Laxmi+Nagar,+Betal+Nagar,+Kondhwa,+Pune,+Maharashtra+411048/@18.4904813,73.8286728,13z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x3bc2bf2e67461101:0x828d43bf9d9ee343!2m2!1d73.8567437!2d18.5204303!1m5!1m1!1s0x3bc2eaf42e26fa71:0x2a9a1928beae9eec!2m2!1d73.8835829!2d18.460303!3e0?entry=ttu" },
            { name: "Priya Sharma", description: "Graphic Designer at Creative Minds Design Studio", photoUrl: "P9.jpg", location: "New+Delhi,+India" },
            { name: "Amit Kumar", description: "Financial Analyst at Global Finance Corporation", photoUrl: "P3.jpg", location: "Mumbai,+Maharashtra" },
            { name: "Sneha Gupta", description: "Marketing Manager at Digital Marketing Solutions", photoUrl: "P8.jpg", location: "Bangalore,+Karnataka" },
            { name: "Ravi Singh", description: "Human Resources Manager at LeadingTech Inc.", photoUrl: "P5.jpg", location: "Hyderabad,+Telangana" },
            { name: "Surya Verma", description: "Software Developer at Tech Solutions Pvt. Ltd.", photoUrl: "P4.jpg", location: "Chennai,+Tamil+Nadu" },
            { name: "Nisha Patel", description: "UX Designer at Creative Minds Design Studio", photoUrl: "P6.jpg", location: "Kolkata,+West+Bengal" },
            { name: "Arjun Mishra", description: "Business Analyst at Global Finance Corporation", photoUrl: "P2.jpg", location: "Ahmedabad,+Gujarat" }
        ];

        // Function to add a new profile
        $scope.addProfile = function() {
            var fileInput = document.createElement("input");
            fileInput.type = "file";
            fileInput.accept = "image/*";
            fileInput.addEventListener("change", function(event) {
                $scope.handleFileSelect(event, function(photoUrl) {
                    var name = prompt("Enter name:");
                    var description = prompt("Enter description:");
                    var location = prompt("Enter location:");
                    $scope.addNewProfile(name, description, photoUrl, location);
                });
            });
            fileInput.click();
        };

        // Function to handle file input change
        $scope.handleFileSelect = function(event, callback) {
            var files = event.target.files;
            var file = files[0];
            var reader = new FileReader();
            reader.onload = function(event) {
                var photoUrl = event.target.result;
                callback(photoUrl);
            };
            reader.readAsDataURL(file);
        };

        // Function to add a new profile to the list
        $scope.addNewProfile = function(name, description, photoUrl, location) {
            $scope.profiles.push({ name: name, description: description, photoUrl: photoUrl, location: location });
            $scope.$apply(); // Ensure data binding updates
        };

        // Function to delete a profile
        $scope.deleteProfile = function() {
            var profileToDelete = prompt("Enter the name of the profile to delete:");
            var index = -1;

            $scope.profiles.forEach(function(profile, i) {
                if (profile.name === profileToDelete) {
                    index = i;
                    return; // Exit the loop if found
                }
            });

            if (index !== -1) {
                $scope.profiles.splice(index, 1);
            } else {
                alert("Profile not found.");
            }
        };

        // Function to edit a profile
        $scope.editProfile = function() {
            var profileToEdit = prompt("Enter the name of the profile to edit:");
            $scope.profiles.forEach(function(profile) {
                if (profile.name === profileToEdit) {
                    var newName = prompt("Enter the new name:");
                    var newDescription = prompt("Enter the new description:");
                    var newLocation = prompt("Enter the new location:");
                    profile.name = newName;
                    profile.description = newDescription;
                    profile.location = newLocation;
                }
            });
        };
    });
